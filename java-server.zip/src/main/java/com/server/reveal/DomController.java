package com.server.reveal;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import org.json.JSONArray;
import org.json.JSONObject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/dashboards")
public class DomController {

    @GET
    @Path("/visualizations")
    @Produces(MediaType.APPLICATION_JSON)
    public List<VisualizationChartInfo> getRdashData() {
        System.out.println("In the controller function");
        String dashboardsFolderPath = "dashboards"; 
        List<VisualizationChartInfo> visualizationChartInfoList = new ArrayList<>();

        try {
            File folder = new File(dashboardsFolderPath);
            File[] rdashFiles = folder.listFiles((dir, name) -> name.endsWith(".rdash")); 
            if (rdashFiles == null || rdashFiles.length == 0) {
                System.out.println("No .rdash files found in the folder");
                return visualizationChartInfoList;
            }

            for (File rdashFile : rdashFiles) {
                String fileNameWithoutExtension = rdashFile.getName().replaceFirst("[.][^.]+$", ""); 
                String jsonContent = extractJsonFromRdash(rdashFile.getPath());
                if (jsonContent.isEmpty()) {
                    System.out.println("No JSON content found in the rdash file: " + rdashFile.getName());
                    continue;
                }

                String title = extractTitleFromJson(jsonContent);
                List<VisualizationChartInfo> widgetInfoList = parseWidgetsFromJson(jsonContent, fileNameWithoutExtension, title);
                visualizationChartInfoList.addAll(widgetInfoList);
            }

        } catch (IOException e) {
            System.err.println("Error while reading the rdash files: " + e.getMessage());
            e.printStackTrace();
        }

        return visualizationChartInfoList;
    }

    public String extractJsonFromRdash(String filePath) throws IOException {
        StringBuilder jsonContent = new StringBuilder();
        try (ZipFile zipFile = new ZipFile(filePath)) {
            for (ZipEntry entry : zipFile.stream().toArray(ZipEntry[]::new)) {
                if (entry.getName().endsWith(".json")) {
                    try (InputStream stream = zipFile.getInputStream(entry);
                         BufferedReader reader = new BufferedReader(new InputStreamReader(stream))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            jsonContent.append(line);
                        }
                    }
                    break; 
                }
            }
        } catch (IOException e) {
            System.err.println("Error while extracting JSON from rdash: " + e.getMessage());
            throw e;
        }
        return jsonContent.toString();
    }

    public String extractTitleFromJson(String jsonContent) {
        JSONObject jsonObject = new JSONObject(jsonContent);
        return jsonObject.optString("Title", "Untitled"); 
    }
    
    public List<VisualizationChartInfo> parseWidgetsFromJson(String jsonContent, String dashboardFileName, String dashboardTitle) {
        List<VisualizationChartInfo> widgetInfoList = new ArrayList<>();
        JSONObject jsonObject = new JSONObject(jsonContent);
    
        if (!jsonObject.has("Widgets")) {
            System.out.println("No widgets found in the JSON");
            return widgetInfoList;
        }
    
        JSONArray widgets = jsonObject.getJSONArray("Widgets");
    
        for (int i = 0; i < widgets.length(); i++) {
            JSONObject widget = widgets.getJSONObject(i);
    
            String vizId = widget.optString("Id", "Unknown Id");
            String vizTitle = widget.optString("Title", "Untitled");
            JSONObject visualizationSettings = widget.optJSONObject("VisualizationSettings");
            String vizChartType = "Unknown Chart Type"; // Default value
    
            if (visualizationSettings != null) {
                String type = visualizationSettings.optString("_type");
                String viewType = visualizationSettings.optString("ViewType");
                String chartType = visualizationSettings.optString("ChartType");
    
                if ("GaugeVisualizationSettingsType".equals(type)) {
                    // Set vizChartType based on ViewType
                    switch (viewType) {
                        case "Linear":
                            vizChartType = "LinearGauge";
                            break;
                        case "Circular":
                            vizChartType = "CircularGauge";
                            break;
                        case "SingleValue":
                            vizChartType = "Text";
                            break;
                        case "BulletGraph":
                            vizChartType = "BulletGraph";
                            break;
                        default:
                            vizChartType = "Unknown Gauge Type";
                            break;
                    }
                } else if ("ChartVisualizationSettingsType".equals(type)) {
                    // Set vizChartType for ChartVisualizationSettingsType
                    if ("Composite".equals(chartType)) {
                        vizChartType = "Combo";
                    } else {
                        vizChartType = chartType;
                    }
                } else {
                    // Handle other VisualizationSettings types
                    switch (type) {
                        case "IndicatorVisualizationSettingsType":
                            vizChartType = "KpiTime";
                            break;
                        case "SingleRowVisualizationSettingsType":
                            vizChartType = "TextView";
                            break;
                        case "IndicatorTargetVisualizationSettingsType":
                            vizChartType = "KpiTarget";
                            break;
                        case "DiyVisualizationSettingsType":
                            vizChartType = "Custom";
                            break;
                        case "AssetVisualizationSettingsType":
                            vizChartType = "Image";
                            break;
                        case "GridVisualizationSettingsType":
                            vizChartType = "Grid";
                            break;
                        case "TreeMapVisualizationSettingsType":
                            vizChartType = "TreeMap";
                            break;
                        case "PivotVisualizationSettingsType":
                            vizChartType = "Pivot";
                            break;
                        case "ChoroplethMapVisualizationSettingsType":
                            vizChartType = "Choropleth";
                            break;
                        default:
                            vizChartType = visualizationSettings.optString("ChartType", "Unknown Chart Type");
                            System.out.println(type + " : " + vizChartType);
                            break;
                    }
                }
            }
    
            String vizImageUrl = getImageUrl(vizChartType);
            widgetInfoList.add(new VisualizationChartInfo(
                    dashboardFileName, dashboardTitle, vizId, vizTitle, vizChartType, vizImageUrl
            ));
        }
        return widgetInfoList;
    }
        

    public String getImageUrl(String input) {
        String visualizationSuffix = "Visualization";
        if (input.toLowerCase().endsWith(visualizationSuffix.toLowerCase())) {
            input = input.substring(0, input.length() - visualizationSuffix.length()).trim();
        }

        /*
         * The below code is commented if you'd like to hard-code a path to the images
         */
        // String dashboardImagePath = "/images/";
        // return dashboardImagePath + input + ".png";

        return input + ".png";
    }    
}