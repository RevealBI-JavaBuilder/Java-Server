package com.server.reveal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevealApplication {

    public static void main(String[] args) {
        SpringApplication.run(RevealApplication.class, args);
    }
}
